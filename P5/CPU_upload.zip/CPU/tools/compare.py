import re
import sys


def cmp(num):
    # 读取三个txt文件
    file1 = open(num + '-myoutput.txt', "r")
    file2 = open(num + '-zqyoutput.txt', "r")
    file3 = open(num + '-ans.txt', "r")


    text1 = file1.read()
    text2 = file2.read()
    text3 = file3.read()

    file1.close()
    file2.close()
    file3.close()

    # 由于不同程序的结果输出数据的时间可能有差异，且Mars输出的结果不带有时间，所以采用正则表达式匹配，并构造(指令地址，写入对象，写入数据三元组)
    obj = re.compile(r".*?@(?P<pc>.*?): (?P<place>.*?) <= (?P<number>.*?)\n", re.S)
    result1 = obj.finditer(text1)
    result2 = obj.finditer(text2)
    result3 = obj.finditer(text3)

    operation1 = []
    operation2 = []
    operation3 = []

    res = open(num + '-diff.txt', 'w')
    flag = True

    for it in result1:
        operation1.append((it.group('pc'), it.group('place'), it.group('number')))
    for it in result2:
        operation2.append((it.group('pc'), it.group('place'), it.group('number')))
    for it in result3:
        operation3.append((it.group('pc'), it.group('place'), it.group('number')))

    # 将三元组按照指令地址排序
    operation1.sort(key=lambda x: x[0])
    operation2.sort(key=lambda x: x[0])
    operation3.sort(key=lambda x: x[0])

    if not (len(operation1) == len(operation2) and len(operation2) == len(operation3)):
        flag = False
        res.write("diff in length\n")
        res.write("len(res1) = {}\n".format(len(operation1)))
        res.write("len(res2) = {}\n".format(len(operation2)))
        res.write("len(res3) = {}\n\n".format(len(operation3)))

    for i in range(min(len(operation1), len(operation2), len(operation3))):
        if not (operation1[i] == operation2[i] and operation2[i] == operation3[i]):
            flag = False
            res.write("diff in len({})\n".format(i + 1))
            res.write("res1 = {}\n".format(operation1[i]))
            res.write("res2 = {}\n".format(operation2[i]))
            res.write("res3 = {}\n\n".format(operation3[i]))

    if flag:
        print("完全正确")


if __name__ == "__main__":
    for i in range(1, len(sys.argv)):
        strs = sys.argv[i]
        cmp(strs)
